<html>
	<head></head>
<body>
	<h2>Offensive Security SQL Injection Exercises</h2>
	<a href="exercise_1.php">Exercise 1</a><br />
	<a href="exercise_2.php">Exercise 2</a><br />
	<a href="exercise_3.php">Exercise 3</a><br />
</body>
</html>